Zane Wang
zwang252
B00810608

I couldn't get the BTB working correctly, it is miscounting the total number of
predicted branches from bimodal_1bit with 512 allocated memory locations. It is
also miscounting the number of correct branches, perhaps due to the incorrect
counting issue.