#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

//increments the counter by 1 if prediction is actually taken
void alwaystaken(int &takencount, string behavior) {
  if (behavior == "T") {
    takencount += 1;
  }
}

void nevertaken(int &ntakencount, string behavior) {
  if (behavior == "NT") {
    ntakencount += 1;
  }
}

bool bimodal_1bit(int &bi1count, string table[], unsigned long long address, string behavior) {
  if (behavior == "T") {
    if (table[address] == "1") {
      bi1count += 1;
      return true;
    }
    table[address] = "1";
  }
  else if (behavior == "NT") {
    if (table[address] == "0") {
      bi1count += 1;
    }
    table[address] = "0";
  }
  return false;
}

bool bimodal_2bit(int &bi2count, string table[], unsigned long long address, string behavior) {
  if (behavior == "T") {
    if (table[address] == "11" || table[address] == "10") {
      table[address] = "11";
      bi2count += 1;
      return true;
    }
    else if (table[address] == "01") {
      table[address] = "10";
    }
    else if (table[address] == "00") {
      table[address] = "01";
    }
  }
  else if (behavior == "NT") {
    if (table[address] == "00" || table[address] == "01") {
      table[address] = "00";
      bi2count += 1;
      return true;
    }
    else if (table[address] == "10") {
      table[address] = "01";
    }
    else if (table[address] == "11") {
      table[address] = "10";
    }
  }
  return false;
}

bool gshare(int &gcount, string table[], unsigned long long address, int histsize, int &hist, string behavior) {
  int maphistsize[] = {8,16,32,64,128,256,512,1024,2048};
  int temp = hist % maphistsize[histsize - 3];
  temp = (address % 2048) ^ temp;

  if (behavior == "T") {
    if (table[temp] == "11") {
      table[temp] = "11";
      gcount += 1;
      return true;
    }
    else if (table[temp] == "10") {
      table[temp] = "11";
      gcount += 1;
      return true;
    }
    else if (table[temp] == "01") {
      table[temp] = "10";
    }
    else if (table[temp] == "00") {
      table[temp] = "01";
    }
  }

  if (behavior == "NT") {
    if (table[temp] == "11") {
      table[temp] = "10";
    }
    else if (table[temp] == "10") {
      table[temp] = "01";
    }
    else if (table[temp] == "01") {
      table[temp] = "00";
      gcount += 1;
      return true;
    }
    else if (table[temp] == "00") {
      table[temp] = "00";
      gcount += 1;
      return true;
    }
  }
  return false;
}

void tournament(int &tourncounter, string gtable[], string bitable[], string selector[], int &hist, unsigned long long address, string behavior) {
  int temp = (address % 2048);
  bool favorg = gshare(tourncounter, gtable, address, 11, hist, behavior);
  bool favorbi = bimodal_2bit(tourncounter, bitable, address % 2048, behavior);
  if (selector[temp] == "00" || selector[temp] == "01") {
    if (favorbi) {
      tourncounter -= 1;
    }
  }
  else if (selector[temp] == "10" || selector[temp] == "11") {
    if (favorg) {
      tourncounter -= 1;
    }
  }
  if (favorg == favorbi) {
    selector[temp] = selector[temp];
  }
  else if (favorg == true) {
    if (selector[temp] == "00" || selector[temp] == "01") {
      selector[temp] = "00";
    }
    else if (selector[temp] == "10") {
      selector[temp] = "01";
    }
    else {
      selector[temp] = "10";
    }
  }
  else if (favorbi == true) {
    if (selector[temp] == "11" || selector[temp] == "10") {
      selector[temp] = "11";
    }
    else if (selector[temp] == "01") {
      selector[temp] = "10";
    }
    else {
      selector[temp] = "01";
    }
  }
}

void btb(int &btbcount, int &numpredictions, string tabletaken[], int table[], unsigned long long address, string behavior, int target) {
  bool pretaken = bimodal_1bit(numpredictions, tabletaken, address, behavior);
  if (!(pretaken)) {
    numpredictions -= 1;
  }
  if (pretaken) {
    unsigned long long temp = table[address];
    if (behavior == "T") {
      if (temp == target) {
	btbcount += 1;
      }
      table[address] = target;
    }
  }
}

int main(int argc, char *argv[]) {

  unsigned long long addr;
  string behavior, line;
  unsigned long long target;

  ifstream infile(argv[1]);
  ofstream outfile(argv[2]);

  int numlines = 0;
  int atake = 0;
  int ntake = 0;
  string table1_16[16];
  for (int i = 0; i < 16; i++) {
    table1_16[i] = "1";
  }
  string table1_32[32];
  for (int i = 0; i < 32; i++) {
    table1_32[i] = "1";
  }
  string table1_128[128];
  for (int i = 0; i < 128; i++) {
    table1_128[i] = "1";
  }
  string table1_256[256];
  for (int i = 0; i < 256; i++) {
    table1_256[i] = "1";
  }
  string table1_512[512];
  for (int i = 0; i < 512; i++) {
    table1_512[i] = "1";
  }
  string table1_1024[1024];
  for (int i = 0; i < 1024; i++) {
    table1_1024[i] = "1";
  }
  string table1_2048[2048];
  for (int i = 0; i < 2048; i++) {
    table1_2048[i] = "1";
  }
  int bimod1_16 = 0;
  int bimod1_32 = 0;
  int bimod1_128 = 0;
  int bimod1_256 = 0;
  int bimod1_512 = 0;
  int bimod1_1024 = 0;
  int bimod1_2048 = 0;
  string table2_16[16];
  for (int i = 0; i < 16; i++) {
    table2_16[i] = "11";
  }
  string table2_32[32];
  for (int i = 0; i < 32; i++) {
    table2_32[i] = "11";
  }
  string table2_128[128];
  for (int i = 0; i < 128; i++) {
    table2_128[i] = "11";
  }
  string table2_256[256];
  for (int i = 0; i < 256; i++) {
    table2_256[i] = "11";
  }
  string table2_512[512];
  for (int i = 0; i < 512; i++) {
    table2_512[i] = "11";
  }
  string table2_1024[1024];
  for (int i = 0; i < 1024; i++) {
    table2_1024[i] = "11";
  }
  string table2_2048[2048];
  for (int i = 0; i < 2048; i++) {
    table2_2048[i] = "11";
  }
  int bimod2_16 = 0;
  int bimod2_32 = 0;
  int bimod2_128 = 0;
  int bimod2_256 = 0;
  int bimod2_512 = 0;
  int bimod2_1024 = 0;
  int bimod2_2048 = 0;

  string gtable_3[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_3[i] = "11";
  }
  string gtable_4[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_4[i] = "11";
  }
  string gtable_5[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_5[i] = "11";
  }
  string gtable_6[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_6[i] = "11";
  }
  string gtable_7[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_7[i] = "11";
  }
  string gtable_8[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_8[i] = "11";
  }
  string gtable_9[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_9[i] = "11";
  }
  string gtable_10[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_10[i] = "11";
  }
  string gtable_11[2048];
  for (int i = 0; i < 2048; i++) {
    gtable_11[i] = "11";
  }
  int ghist = 0;
  int gs_3 = 0;
  int gs_4 = 0;
  int gs_5 = 0;
  int gs_6 = 0;
  int gs_7 = 0;
  int gs_8 = 0;
  int gs_9 = 0;
  int gs_10 = 0;
  int gs_11 = 0;

  int tourn = 0;
  int tournhist = 0;
  string tourngtable[2048];
  for (int i = 0; i < 2048; i++) {
    tourngtable[i] = "11";
  }
  string tournbitable[2048];
  for (int i = 0; i < 2048; i++) {
    tournbitable[i] = "11";
  }
  string selectable[2048];
  for (int i = 0; i < 2048; i++) {
    selectable[i] = "00";
  }

  int bt = 0;
  int btcount = 0;
  int btbstored[512];
  string btbtable[512];
  for (int i = 0; i < 512; i++) {
    btbtable[i] = "1";
  }

  while (getline(infile, line)) {
    numlines += 1;
    stringstream s(line);
    s >> hex >> addr >> behavior >> hex >> target;
    alwaystaken(atake, behavior);
    nevertaken(ntake, behavior);
    bimodal_1bit(bimod1_16, table1_16, addr & 15, behavior);
    bimodal_1bit(bimod1_32, table1_32, addr & 31, behavior);
    bimodal_1bit(bimod1_128, table1_128, addr & 127, behavior);
    bimodal_1bit(bimod1_256, table1_256, addr & 255, behavior);
    bimodal_1bit(bimod1_512, table1_512, addr & 511, behavior);
    bimodal_1bit(bimod1_1024, table1_1024, addr & 1023, behavior);
    bimodal_1bit(bimod1_2048, table1_2048, addr & 2047, behavior);
    bimodal_2bit(bimod2_16, table2_16, addr & 15, behavior);
    bimodal_2bit(bimod2_32, table2_32, addr & 31, behavior);
    bimodal_2bit(bimod2_128, table2_128, addr & 127, behavior);
    bimodal_2bit(bimod2_256, table2_256, addr & 255, behavior);
    bimodal_2bit(bimod2_512, table2_512, addr & 511, behavior);
    bimodal_2bit(bimod2_1024, table2_1024, addr & 1023, behavior);
    bimodal_2bit(bimod2_2048, table2_2048, addr & 2047, behavior);
    gshare(gs_3, gtable_3, addr, 3, ghist, behavior);
    gshare(gs_4, gtable_4, addr, 4, ghist, behavior);
    gshare(gs_5, gtable_5, addr, 5, ghist, behavior);
    gshare(gs_6, gtable_6, addr, 6, ghist, behavior);
    gshare(gs_7, gtable_7, addr, 7, ghist, behavior);
    gshare(gs_8, gtable_8, addr, 8, ghist, behavior);
    gshare(gs_9, gtable_9, addr, 9, ghist, behavior);
    gshare(gs_10, gtable_10, addr, 10, ghist, behavior);
    gshare(gs_11, gtable_11, addr, 11, ghist, behavior);
    
    ghist = (ghist * 2) % 2048;
    if (behavior == "T") {
      ghist += 1;
    }

    tournament(tourn, tourngtable, tournbitable, selectable, tournhist, addr, behavior);

    tournhist = (tournhist * 2) % 2048;
    if (behavior == "T") {
      tournhist += 1;
    }

    btb(bt, btcount, btbtable, btbstored, addr & 511, behavior, target);
  }

  outfile << atake << "," << numlines << "; " << endl;

  outfile << ntake << "," << numlines << "; " << endl;

  outfile << bimod1_16 << "," << numlines << "; ";
  outfile << bimod1_32 << "," << numlines << "; ";
  outfile << bimod1_128 << "," << numlines << "; ";
  outfile << bimod1_256 << "," << numlines << "; ";
  outfile << bimod1_512 << "," << numlines << "; ";
  outfile << bimod1_1024 << "," << numlines << "; ";
  outfile << bimod1_2048 << "," << numlines << "; " << endl;

  outfile << bimod2_16 << "," << numlines << "; ";
  outfile << bimod2_32 << "," << numlines << "; ";
  outfile << bimod2_128 << "," << numlines << "; ";
  outfile << bimod2_256 << "," << numlines << "; ";
  outfile << bimod2_512 << "," << numlines << "; ";
  outfile << bimod2_1024 << "," << numlines << "; ";
  outfile << bimod2_2048 << "," << numlines << "; " << endl;

  outfile << gs_3 << "," << numlines << "; ";
  outfile << gs_4 << "," << numlines << "; ";
  outfile << gs_5 << "," << numlines << "; ";
  outfile << gs_6 << "," << numlines << "; ";
  outfile << gs_7 << "," << numlines << "; ";
  outfile << gs_8 << "," << numlines << "; ";
  outfile << gs_9 << "," << numlines << "; ";
  outfile << gs_10 << "," << numlines << "; ";
  outfile << gs_11 << "," << numlines << "; " << endl;

  outfile << tourn << "," << numlines << "; " << endl;

  outfile << bt << "," << btcount << "; " << endl;
  
  outfile.close();
  return 0;
}
